import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';

import '../../services/auth_service.dart';
import '../../core/constants/app_colors.dart';

class ProfileScreen extends StatefulWidget {
  final String currentName;
  final String currentEmail;

  ProfileScreen({
    super.key,
    required this.currentName,
    required this.currentEmail,
  });

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late TextEditingController nameCtrl;
  late TextEditingController emailCtrl;

  String avatarPath = '';
  String serverAvatarUrl = '';
  String avatarVersion = '';
  bool changingPassword = false;
  bool loadingSummary = true;

  String latestMbti = 'Chưa có';
  String packageName = 'Miễn phí';
  String joinedDate = 'Chưa rõ';

  int selectedAvatar = 0;

  String get avatarPathKey => 'user_avatar_path_${widget.currentEmail}';
  String get avatarIndexKey => 'user_avatar_index_${widget.currentEmail}';

  final avatars = [
    Icons.person_rounded,
    Icons.face_rounded,
    Icons.school_rounded,
    Icons.psychology_rounded,
    Icons.auto_awesome_rounded,
  ];

  bool get isDark => Theme.of(context).brightness == Brightness.dark;

  Color get bg => isDark ? Color(0xFF000000) : AppColors.lightBlue;
  Color get card => isDark ? Color(0xFF111111) : Colors.white;
  Color get title => isDark ? Color(0xFFEAF6FF) : AppColors.textDark;
  Color get sub => isDark ? Color(0xFF94A3B8) : AppColors.textGrey;
  Color get border => isDark ? Color(0xFF2A2A2A) : AppColors.borderColor;

  @override
  void initState() {
    super.initState();
    nameCtrl = TextEditingController(text: widget.currentName);
    emailCtrl = TextEditingController(text: widget.currentEmail);
    loadAvatar();
    loadProfileSummary();
  }

  Future<void> loadAvatar() async {
    final prefs = await SharedPreferences.getInstance();

    if (!mounted) return;

    final localPath = prefs.getString(avatarPathKey) ?? '';

    setState(() {
      selectedAvatar = prefs.getInt(avatarIndexKey) ?? 0;
      avatarPath = File(localPath).existsSync() ? localPath : '';
      serverAvatarUrl = prefs.getString('user_avatar_url') ?? '';
    });
  }

  Future<void> loadProfileSummary() async {
    try {
      final data = await AuthService.getProfileSummary();

      final user = data['user'];
      final package = data['package'];
      final mbti = data['mbti'];

      if (!mounted) return;

      final freshName = user?['name']?.toString() ?? '';
      final freshEmail = user?['email']?.toString() ?? '';
      final freshAvatarUrl = AuthService.resolveAvatarUrl(
            user?['avatar_url'] ??
                user?['avatar'] ??
                user?['profile_photo_url'],
          ) ??
          '';

      final prefs = await SharedPreferences.getInstance();

      if (freshAvatarUrl.isNotEmpty) {
        await prefs.setString('user_avatar_url', freshAvatarUrl);
        await prefs.remove(avatarPathKey);
      }

      setState(() {
        if (freshName.isNotEmpty) {
          nameCtrl.text = freshName;
        }

        if (freshEmail.isNotEmpty) {
          emailCtrl.text = freshEmail;
        }

        if (freshAvatarUrl.isNotEmpty) {
          serverAvatarUrl = freshAvatarUrl;
          avatarPath = '';
          avatarVersion = user?['updated_at']?.toString() ??
              DateTime.now().millisecondsSinceEpoch.toString();
        }

        latestMbti =
            mbti?['mbti_type'] ??
            mbti?['type'] ??
            mbti?['result'] ??
            mbti?['code'] ??
            'Chưa có';

        packageName = package?['name'] ?? 'Miễn phí';
        joinedDate = formatDate(user?['created_at']);
        loadingSummary = false;
      });
    } catch (_) {
      if (!mounted) return;

      setState(() {
        loadingSummary = false;
      });
    }
  }

  String formatDate(dynamic value) {
    if (value == null) return 'Chưa rõ';

    try {
      final date = DateTime.parse(value.toString());
      return '${date.day.toString().padLeft(2, '0')}/'
          '${date.month.toString().padLeft(2, '0')}/'
          '${date.year}';
    } catch (_) {
      return 'Chưa rõ';
    }
  }

  Future<void> saveProfile() async {
    if (nameCtrl.text.trim().isEmpty || emailCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Vui lòng nhập đầy đủ thông tin')),
      );
      return;
    }

    try {
      final data = await AuthService.updateProfile(
        name: nameCtrl.text.trim(),
        email: emailCtrl.text.trim(),
        avatarPath: avatarPath.isNotEmpty ? avatarPath : null,
      );

      final prefs = await SharedPreferences.getInstance();
      final updatedAvatarUrl = AuthService.extractAvatarUrl(data) ?? '';

      await prefs.setInt(avatarIndexKey, selectedAvatar);

      if (updatedAvatarUrl.isNotEmpty) {
        await prefs.setString('user_avatar_url', updatedAvatarUrl);
        await prefs.remove(avatarPathKey);
      } else if (avatarPath.isNotEmpty) {
        await prefs.setString(avatarPathKey, avatarPath);
      }

      if (!mounted) return;

      setState(() {
        if (updatedAvatarUrl.isNotEmpty) {
          serverAvatarUrl = updatedAvatarUrl;
          avatarPath = '';
          avatarVersion = DateTime.now().millisecondsSinceEpoch.toString();
        }
      });

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Đã cập nhật hồ sơ')));

      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
      );
    }
  }

  Future<void> showChangePasswordDialog() async {
    final currentCtrl = TextEditingController();
    final newCtrl = TextEditingController();
    final confirmCtrl = TextEditingController();

    bool hideCurrent = true;
    bool hideNew = true;
    bool hideConfirm = true;
    bool dialogLoading = false;

    await showDialog(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              backgroundColor: card,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(22),
              ),
              title: Text(
                'Đổi mật khẩu',
                style: TextStyle(color: title, fontWeight: FontWeight.w900),
              ),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    passwordField(
                      controller: currentCtrl,
                      hint: 'Mật khẩu hiện tại',
                      hide: hideCurrent,
                      onToggle: () {
                        setDialogState(() {
                          hideCurrent = !hideCurrent;
                        });
                      },
                    ),
                    SizedBox(height: 12),
                    passwordField(
                      controller: newCtrl,
                      hint: 'Mật khẩu mới',
                      hide: hideNew,
                      onToggle: () {
                        setDialogState(() {
                          hideNew = !hideNew;
                        });
                      },
                    ),
                    SizedBox(height: 12),
                    passwordField(
                      controller: confirmCtrl,
                      hint: 'Xác nhận mật khẩu mới',
                      hide: hideConfirm,
                      onToggle: () {
                        setDialogState(() {
                          hideConfirm = !hideConfirm;
                        });
                      },
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: dialogLoading
                      ? null
                      : () => Navigator.pop(dialogContext),
                  child: Text('Hủy', style: TextStyle(color: sub)),
                ),
                ElevatedButton(
                  onPressed: dialogLoading
                      ? null
                      : () async {
                          if (currentCtrl.text.isEmpty ||
                              newCtrl.text.isEmpty ||
                              confirmCtrl.text.isEmpty) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text('Vui lòng nhập đầy đủ thông tin'),
                              ),
                            );
                            return;
                          }

                          if (newCtrl.text != confirmCtrl.text) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text('Mật khẩu xác nhận không khớp'),
                              ),
                            );
                            return;
                          }

                          setDialogState(() {
                            dialogLoading = true;
                          });

                          try {
                            await AuthService.changePassword(
                              currentPassword: currentCtrl.text,
                              newPassword: newCtrl.text,
                              confirmPassword: confirmCtrl.text,
                            );

                            if (!mounted) return;

                            if (Navigator.canPop(dialogContext)) {
                              Navigator.pop(dialogContext);
                            }

                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text('Đổi mật khẩu thành công'),
                              ),
                            );
                          } catch (e) {
                            if (!mounted) return;

                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(
                                  e.toString().replaceFirst('Exception: ', ''),
                                ),
                              ),
                            );

                            setDialogState(() {
                              dialogLoading = false;
                            });
                          }
                        },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryBlue,
                    foregroundColor: Colors.white,
                  ),
                  child: dialogLoading
                      ? SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : Text('Lưu'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> pickAvatar() async {
    final picker = ImagePicker();

    final image = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 80,
    );

    if (image == null) return;

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(avatarPathKey, image.path);

    if (!mounted) return;

    setState(() {
      avatarPath = image.path;
    });
  }

  @override
  void dispose() {
    nameCtrl.dispose();
    emailCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: AppColors.bg(context),
        foregroundColor: AppColors.title(context),
        elevation: 0,
        iconTheme: IconThemeData(color: title),
        title: Text(
          'Hồ sơ cá nhân',
          style: TextStyle(color: title, fontWeight: FontWeight.w900),
        ),
      ),
      body: SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(
            20,
            16,
            20,
            MediaQuery.of(context).padding.bottom + 30,
          ),
          child: Column(
            children: [
              profileHeaderCard(),
              SizedBox(height: 18),
              profileSummaryCard(),
              SizedBox(height: 18),
              editProfileCard(),
            ],
          ),
        ),
      ),
    );
  }


  ImageProvider? avatarImageProvider() {
    if (avatarPath.isNotEmpty && File(avatarPath).existsSync()) {
      return FileImage(File(avatarPath));
    }

    if (serverAvatarUrl.isNotEmpty) {
      final separator = serverAvatarUrl.contains('?') ? '&' : '?';
      final version = avatarVersion.isNotEmpty
          ? avatarVersion
          : DateTime.now().millisecondsSinceEpoch.toString();

      return NetworkImage('$serverAvatarUrl${separator}v=$version');
    }

    return null;
  }

  Widget profileHeaderCard() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: AppColors.border(context)),
      ),
      child: Column(
        children: [
          Stack(
            children: [
              GestureDetector(
                onTap: pickAvatar,
                child: CircleAvatar(
                  radius: 48,
                  backgroundColor: isDark
                      ? Color(0xFF1A1A1A)
                      : Color(0xFFEAF6FF),
                  backgroundImage: avatarImageProvider(),
                  child: avatarImageProvider() == null
                      ? Icon(
                          avatars[selectedAvatar],
                          color: AppColors.primaryBlue,
                          size: 50,
                        )
                      : null,
                ),
              ),
              Positioned(
                right: 0,
                bottom: 0,
                child: GestureDetector(
                  onTap: pickAvatar,
                  child: Container(
                    width: 34,
                    height: 34,
                    decoration: BoxDecoration(
                      color: AppColors.primaryBlue,
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.border(context)),
                    ),
                    child: Icon(
                      Icons.edit_rounded,
                      color: Colors.white,
                      size: 18,
                    ),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 16),
          Text(
            nameCtrl.text.trim().isEmpty
                ? 'Người dùng NAVI'
                : nameCtrl.text.trim(),
            textAlign: TextAlign.center,
            style: TextStyle(
              color: title,
              fontSize: 22,
              fontWeight: FontWeight.w900,
            ),
          ),
          SizedBox(height: 4),
          Text(
            emailCtrl.text.trim(),
            textAlign: TextAlign.center,
            style: TextStyle(
              color: sub,
              fontSize: 13.5,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget profileSummaryCard() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.border(context)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Thông tin tài khoản',
            style: TextStyle(
              color: title,
              fontSize: 16,
              fontWeight: FontWeight.w900,
            ),
          ),
          SizedBox(height: 14),
          if (loadingSummary)
            Center(
              child: Padding(
                padding: EdgeInsets.all(12),
                child: CircularProgressIndicator(color: AppColors.primaryBlue),
              ),
            )
          else ...[
            profileInfoTile(
              Icons.psychology_rounded,
              'Nhóm MBTI gần nhất',
              latestMbti,
            ),
            profileInfoTile(
              Icons.workspace_premium_rounded,
              'Gói hiện tại',
              packageName,
            ),
            profileInfoTile(
              Icons.calendar_month_rounded,
              'Ngày tham gia',
              joinedDate,
            ),
          ],
        ],
      ),
    );
  }

  Widget editProfileCard() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.border(context)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          fieldLabel(Icons.person_rounded, 'Họ tên'),
          SizedBox(height: 8),
          TextField(
            controller: nameCtrl,
            style: TextStyle(color: title),
            onChanged: (_) => setState(() {}),
            decoration: inputDecoration('Nhập họ tên'),
          ),
          SizedBox(height: 16),
          fieldLabel(Icons.email_rounded, 'Email'),
          SizedBox(height: 8),
          TextField(
            controller: emailCtrl,
            style: TextStyle(color: title),
            keyboardType: TextInputType.emailAddress,
            onChanged: (_) => setState(() {}),
            decoration: inputDecoration('Nhập email'),
          ),
          SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            height: 48,
            child: OutlinedButton.icon(
              onPressed: showChangePasswordDialog,
              icon: Icon(Icons.lock_reset_rounded),
              label: Text(
                'Đổi mật khẩu',
                style: TextStyle(fontWeight: FontWeight.w900),
              ),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.primaryBlue,
                side: BorderSide(color: AppColors.primaryBlue),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
            ),
          ),
          SizedBox(height: 22),
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton(
              onPressed: saveProfile,
              style: ElevatedButton.styleFrom(
                elevation: 0,
                backgroundColor: AppColors.primaryBlue,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              child: Text(
                'Lưu thay đổi',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget profileInfoTile(IconData icon, String label, String value) {
    return Container(
      margin: EdgeInsets.only(bottom: 10),
      padding: EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: isDark ? Color(0xFF000000) : Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border(context)),
      ),
      child: Row(
        children: [
          Icon(icon, color: AppColors.primaryBlue),
          SizedBox(width: 12),
          Expanded(
            child: Text(
              label,
              style: TextStyle(color: sub, fontWeight: FontWeight.w700),
            ),
          ),
          Text(
            value,
            style: TextStyle(color: title, fontWeight: FontWeight.w900),
          ),
        ],
      ),
    );
  }

  Widget passwordField({
    required TextEditingController controller,
    required String hint,
    required bool hide,
    required VoidCallback onToggle,
  }) {
    return TextField(
      controller: controller,
      obscureText: hide,
      style: TextStyle(color: title),
      decoration: InputDecoration(
        hintText: hint,
        filled: true,
        fillColor: isDark ? Color(0xFF000000) : Colors.white,
        suffixIcon: IconButton(
          onPressed: onToggle,
          icon: Icon(
            hide ? Icons.visibility_off_rounded : Icons.visibility_rounded,
            color: sub,
          ),
        ),
        hintStyle: TextStyle(color: sub, fontSize: 13),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(color: border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(color: border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(15)),
          borderSide: BorderSide(color: AppColors.primaryBlue, width: 1.5),
        ),
      ),
    );
  }

  Widget fieldLabel(IconData icon, String text) {
    return Row(
      children: [
        Icon(icon, color: AppColors.primaryBlue, size: 19),
        SizedBox(width: 8),
        Text(
          text,
          style: TextStyle(
            color: title,
            fontSize: 13.5,
            fontWeight: FontWeight.w900,
          ),
        ),
      ],
    );
  }

  InputDecoration inputDecoration(String hint) {
    return InputDecoration(
      hintText: hint,
      filled: true,
      fillColor: isDark ? Color(0xFF000000) : Colors.white,
      contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 13),
      hintStyle: TextStyle(
        color: isDark ? Color(0xFF64748B) : Color(0xFFB8C6D3),
        fontSize: 13.5,
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(15),
        borderSide: BorderSide(color: border, width: 1.2),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(15),
        borderSide: BorderSide(color: AppColors.primaryBlue, width: 1.5),
      ),
    );
  }
}
